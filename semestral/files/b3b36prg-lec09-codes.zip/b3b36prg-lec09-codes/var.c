int main(int argc, char *argv[]) 
{
   int v;
   v = 10;
   v = v + 1;
   return argc;
}
